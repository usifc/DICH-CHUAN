# Shadow Tactics: Blades of the Shogun Việt Hóa

## Việt hóa cho phiên bản Game: 1.4.4.f

Các phiên bản cũ xem tại [đây](https://github.com/game-viet-hoa/Shadow-Tactics-Blades-of-the-Shogun-Viet-Hoa/branches/all)

## Hướng dẫn cài đặt

1. Download Game tại [đây](https://www.fshare.vn/folder/4Q3ZGX5K7Z36).

2. Download việt hóa tại [đây](https://github.com/game-viet-hoa/Shadow-Tactics-Blades-of-the-Shogun-Viet-Hoa/archive/master.zip).

3. Giải nén file việt hóa vừa tải về, COPY ĐÈ thư mục `Shadow Tactics_Data` vào thư mục chính của Game.

## Lưu ý

- Phải sử dụng phiên bản việt hóa giống với phiên bản Game. Khác nhau thì Game sẽ bị lỗi.

## Tác giả

- XKVNN [![facebook_icon]](https://www.facebook.com/xkvnn) [![github_icon]](https://github.com/xkvnn)

<!-- icons without padding -->
[facebook_icon]: http://i.imgur.com/fep1WsG.png
[github_icon]: http://i.imgur.com/9I6NRUm.png